<?php
include_once("../servico/Bd.php");

$bd = new Bd();

$id = $_GET['id'];

$sql = "select * from usuario_3002 where id ='$id'";

foreach ($bd->query($sql) as $linha ) {
    $login=$linha['login'];
    $senha=$linha['senha'];
}



?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">

    <link href="assets/fontawesome-free-5.15.1-web/css/fontawesome.css" rel="stylesheet">
    <link href="assets/fontawesome-free-5.15.1-web/css/brands.css" rel="stylesheet">
    <link href="assets/fontawesome-free-5.15.1-web/css/solid.css" rel="stylesheet">

      <script defer src="assets/fontawesome-free-5.15.1-web/js/brands.js"></script>
    <script defer src="assets/fontawesome-free-5.15.1-web/js/solid.js"></script>
    <script defer src="assets/fontawesome-free-5.15.1-web/js/fontawesome.js"></script>
  
  
    <title>Alteração de usuário</title>
    <style>
body {
    color: #566787;
    background: #f5f5f5;
    font-family: 'Roboto', sans-serif;
}
.table-responsive {
    margin: 30px 0;
}
.table-wrapper {
    min-width: 1000px;
    background: #fff;
    padding: 20px;
    box-shadow: 0 1px 1px rgba(0,0,0,.05);
}
.table-title {
    padding-bottom: 10px;
    margin: 0 0 10px;
    min-width: 100%;
}

.search-box {
    position: relative;        
    float: right;
}
.search-box input {
    height: 34px;
    border-radius: 20px;
    padding-left: 35px;
    border-color: #ddd;
    box-shadow: none;
}
.search-box input:focus {
    border-color: #3FBAE4;
}

table.table tr th, table.table tr td {
    border-color: #e9e9e9;
}
table.table-striped tbody tr:nth-of-type(odd) {
    background-color: #fcfcfc;
}
table.table-striped.table-hover tbody tr:hover {
    background: #f5f5f5;
}

  
.pagination {
    float: right;
    margin: 0 0 5px;
}

.hint-text {
    float: left;
    margin-top: 6px;
    font-size: 95%;
}    
</style>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
  </head>
  <body>
      
    <div class="container">
        
         <h1>Seu Idioma!</h1>

         <h6>Tela de Consulta</h6>
            
         <hr>
         <a href="consultaUsuario.php"> < Voltar</a>
         <br><br> 
 <table id="example" class="table table-striped table-hover table-bordered" style="width:100%">  
    
    <form action="salvar.php" method="get">
      <div class="form-group">
        <label for="exampleInputEmail1">Login</label>
        
        <?php
        
        echo "<input type='hidden' name='id' value='$id'>";
        echo '<input type="text" name="login" class="form-control" id="exampleInputEmail1" placeholder="Digite seu usuário" value="'.$login.'">';
        ?>
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">Senha</label>
        <?php
        
        echo '<input type="text" name="senha" class="form-control" id="exampleInputPassword1" placeholder="Digite sua senha"  value="'.$senha.'">';
        ?>
        
        
      </div>
      
      <button type="submit" class="btn btn-primary">Salvar</button>
   </form>
   </table>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>