<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">

    <link href="assets/fontawesome-free-5.15.1-web/css/fontawesome.css" rel="stylesheet">
    <link href="assets/fontawesome-free-5.15.1-web/css/brands.css" rel="stylesheet">
    <link href="assets/fontawesome-free-5.15.1-web/css/solid.css" rel="stylesheet">

      <script defer src="assets/fontawesome-free-5.15.1-web/js/brands.js"></script>
    <script defer src="assets/fontawesome-free-5.15.1-web/js/solid.js"></script>
    <script defer src="assets/fontawesome-free-5.15.1-web/js/fontawesome.js"></script>
  
  
    <title>Exclusão de usuário</title>
    <style>
body {
    color: #566787;
    background: #f5f5f5;
    font-family: 'Roboto', sans-serif;
}
.table-responsive {
    margin: 30px 0;
}
.table-wrapper {
    min-width: 1000px;
    background: #fff;
    padding: 20px;
    box-shadow: 0 1px 1px rgba(0,0,0,.05);
}
.table-title {
    padding-bottom: 10px;
    margin: 0 0 10px;
    min-width: 100%;
}

.search-box {
    position: relative;        
    float: right;
}
.search-box input {
    height: 34px;
    border-radius: 20px;
    padding-left: 35px;
    border-color: #ddd;
    box-shadow: none;
}
.search-box input:focus {
    border-color: #3FBAE4;
}

table.table tr th, table.table tr td {
    border-color: #e9e9e9;
}
table.table-striped tbody tr:nth-of-type(odd) {
    background-color: #fcfcfc;
}
table.table-striped.table-hover tbody tr:hover {
    background: #f5f5f5;
}

  
.pagination {
    float: right;
    margin: 0 0 5px;
}

.hint-text {
    float: left;
    margin-top: 6px;
    font-size: 95%;
}    
</style>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
  </head>

  <body>
<h1>Seu Idioma!</h1>
<hr>
    <div class="container">
        <?php
        include_once("../servico/Bd.php");
        
        $id = $_GET['id'];
        
        $sql = "delete from usuario_3002 where id = '$id'";
        
        $bd= new Bd();
        
        $contador = $bd->exec($sql);
        
        echo "<h1> $contador registro foi excluído com Sucesso!</h1>";
        echo "<a href='consultaUsuario.php'> < Voltar </a>";
        
        
        ?>
        
</div>
	</body>
</html>