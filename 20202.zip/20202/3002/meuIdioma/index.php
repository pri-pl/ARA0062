<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SEU IDIOMA!</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Eterna - v2.1.0
  * Template URL: https://bootstrapmade.com/eterna-free-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <h1 class="text-light"><a href="menu.php"><span>SEU IDIOMA!</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Início</a></li>
          <li><a href="contato.html">Contato</a></li>
          <li><a href="login.html">Login</a></li>         
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <!-- Slide 1 -->
          <div class="carousel-item active" style="background: url(https://inexbrasil.com/wp-content/uploads/2018/03/idioma-aprender-830x464.jpg)">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Bem vindo ao <span>SEU IDIOMA!</span></h2>
                <p class="animate__animated animate__fadeInUp">O lugar onde você aprende o idioma que você quiser com um preço que cabe no seu bolso.</p>
                <a href="" class="btn-get-started animate__animated animate__fadeInUp">Veja mais</a>
              </div>
            </div>
          </div>

          <!-- Slide 2 -->
          <div class="carousel-item" style="background: url(https://m.i.uol.com.br/estilo/2011/05/12/estudante-escola-universitaros-estudos-1305216099646_1920x1275.jpg">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated fanimate__adeInDown">Seja um <span>BOLSISTA</span></h2>
                <p class="animate__animated animate__fadeInUp">Bolsas de até 100% para você realizar seu sonho do idioma.</p>
                <a href="" class="btn-get-started animate__animated animate__fadeInUp">Veja mais</a>
              </div>
            </div>
          </div>

          <!-- Slide 3 -->
          <div class="carousel-item" style="background: url(https://banco.bradesco/assets/classic/img/acessibilidade/pessoa-mexendo-em-notebook.png">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Faça já sua <span>inscrição</span></h2>
                <p class="animate__animated animate__fadeInUp">É fácil, rápido, seguro e para todas as idades.</p>
                <a href="" class="btn-get-started animate__animated animate__fadeInUp">Veja mais</a>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon icofont-rounded-left" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon icofont-rounded-right" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= CARD Section ======= -->
  
  <section id="services" class="services">
      <div class="container">

      <div class="section-title" data-aos="fade-up">
          <h2>Nossos serviços</h2>
      </div>

      <div class="row">
          
          <?php
                    
              include_once("servico/Bd.php");
                        
                $bd = new Bd();
                        
                $sql = "select * from blog_3002";
                        
                foreach ($bd->query($sql) as $row) {
                            
                echo '
                <div class="card bg-light mb-3" style="max-width: 18rem;">
                  <div class="card-header">'.$row['titulo'].'</div>
                  <div class="card-body">
                    <p class="card-text">'.substr($row['corpo'],0,100).' ...</p>
                    <a href "#" class="card-link">Leia mais</a>
                  </div>
                </div>
            
                ';

                }
                    
          ?>
      </div>       
    </div> 
    </section> <!-- ======= end of CARD Section ======= -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row">
          <div class="col-lg-6">
            <img src="https://ynner.com.br/wp-content/uploads/2014/01/grupo-estudando-1.jpg">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content">
            <h3>Conheça o maior curso de idiomas do país</h3>
           
            <ul>
              <li><i class="icofont-check-circled"></i> Professores licenciados.</li>
              <li><i class="icofont-check-circled"></i> Aulas presenciais e online.</li>
              <li><i class="icofont-check-circled"></i> Certificado no fim do curso.</li>
            </ul>
            <p>
              Tudo para você não ficar de fora dessa.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

   
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>SEU IDIOMA!</span></strong> All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/eterna-free-multipurpose-bootstrap-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a><br>
        Modificado por Marcella Januario e Priscila Patricio
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/jquery-sticky/jquery.sticky.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>