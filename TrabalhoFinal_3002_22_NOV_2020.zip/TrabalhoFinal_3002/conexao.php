<?php

//Conectando Banco de Dados
$servidor = 'localhost';
$nomeBD = 'id14818778_site_final_3002';
$usuarioBD = 'id14818778_admin';
$senhaBD = 'yNuG3by2fINMGJ%2';
$con = mysql_connect($servidor, $usuarioBD, $senhaBD) or die
 ("Sem conexão com o servidor");
$condb = mysql_select_db($nomeBD,$con) or die("Sem acesso ao Banco, Entre em
contato com o Administrador");
?>